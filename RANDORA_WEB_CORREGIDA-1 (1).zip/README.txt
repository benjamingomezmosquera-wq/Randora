# RANDORA — sitio web
Abrí `index.html` en un navegador.

Incluye:
- 20 productos tomados del archivo base de RANDORA.
- Precios y stock del catálogo.
- Buscador y ordenamiento.
- Filtros por sucursal.
- Carrito funcional con localStorage.
- Selector de tema: violeta, azul, amarillo/dorado y blanco/negro.
- Sección sobre RANDORA basada en el documento de preguntas.

Actualización: las tarjetas usan ilustraciones SVG locales en assets/products (no emojis) y el logo se muestra con ajuste de tamaño para cabecera y portada. Son ilustraciones representativas, no fotografías exactas de cada producto.
